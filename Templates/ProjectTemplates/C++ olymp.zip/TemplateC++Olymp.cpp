//default
#include <iostream>
#include <vector>
#include <algorithm>
/*
//Graphs
#include <map>
#include <set>
#include <limits>
/*
//Containers
#include<deque>
#include<stack>
#include<queue>
/*
//Functional
#include<functional>
*/
#define INF numeric_limits<unsigned>::max()
#define un unsigned

using namespace std;


int main()
{
	un n;
	cin >> n;
	vector<int> arr(n);
	for (un i = 0; i < n; ++i)
		cin >> arr[i];




	for (un i = 0; i < n; ++i)
		cout << arr[i];
}